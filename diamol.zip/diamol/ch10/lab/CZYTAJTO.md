# Rozdział 10. - Laboratorium - Przykładowe rozwiązanie

## Środowisko do prac programistycznych

```
docker-compose up -d
```

## Środowisko testowe

```
docker-compose -f .\docker-compose.yml -f .\docker-compose-test.yml -p ch10-lab-test up -d
```

> Dane będą zachowywane niezależnie od uruchamiani i zatrzymywania poszczególnych środowisk (poleceniami `up` and `down`), gdyż kontener bazy danych używa woluminu.
