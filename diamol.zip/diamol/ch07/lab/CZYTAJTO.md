# Rozdział 7. - Laboratorium - Przykładowe rozwiązanie

## Środowisko do prac programistycznych

Ta konfiguracja używa bazy Sqlite do przechowywania danych i publikuje aplikację internetową na porcie `8020`.

Uruchom kontener z bieżącego katalogu używając w tym celu następującego polecenia:

```
docker-compose -f docker-compose-dev.yml up -d
```

## Środowisko testowe

```
mkdir -p /data/postgres

docker-compose -f docker-compose-test.yml up -d
```

Lub w systemie Windows:

```
mkdir -p /data/postgres

docker-compose -f docker-compose-test-windows.yml up -d
```
