https://github.com/nats-io/go-nats-examples/blob/master/tools/nats-sub/nats-sub.go

(no Arm builds)
