# STATUS: STALLED

Fails to build on 32-bit Arm; stalled in favour of Postgres