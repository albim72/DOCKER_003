# Rozdział 13. - Laboratorium - Przykładowe rozwiązanie

Wykonaj poniższe polecenie, aby wdrożyć stos:

```
docker stack deploy -c image-gallery.yml image-gallery
```

W przeglądarce wyświetl stronę *http://localhost* (w przypadku używania kontenerów z systemem Windows zrób to z innego komputera podłączonego do sieci lokalnej). Postać aplikacji przedstawiłem na poniższym rysunku (w Twoim przypadku będzie ona prezentować inne zdjęcie).

![](solution.png)
